import numpy
import shutil
import argparse
import os

def create_args():
    parser = argparse.ArgumentParser()
    # Testing settings
    parser.add_argument('--input_path', type=str, default='/home/harry/yolo/hls/test.m3u8')
    parser.add_argument('--output_dir', type=str, default='/home/xuh/')
    args = parser.parse_args()
    return args

if __name__ == "__main__":
    args = create_args()
    input_path = args.input_path
    output_dir = args.output_dir
    shutil.copy(input_path,os.path.join(output_dir,os.path.basename(input_path)))
