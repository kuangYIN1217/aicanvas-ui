import numpy

print('succ')

with open('out','w') as f:
    pass
